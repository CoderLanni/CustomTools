//
//  GVUserDefaults+Properties.m
//  DUGeneral
//
//  Created by 小毅 on 2018/5/31.
//  Copyright © 2018年 小毅. All rights reserved.
//

#import "GVUserDefaults+Properties.h"

@implementation GVUserDefaults (Properties)

@dynamic userName;
@dynamic password;
@dynamic userId;
@dynamic token;
@dynamic referenPhone;
@dynamic nickName;
@dynamic referenName;
@dynamic referenId;
@dynamic isReferen;
@dynamic authStatus;
@dynamic phone;
@dynamic headImgUrl;
@dynamic authType;
@dynamic isNewUser;
@dynamic nonce;
@dynamic userIdMD5;



 @dynamic appSecret;


#pragma mark - 医小助 
@dynamic  gender;
@dynamic   serviceType;
@dynamic   isNurse;
@dynamic   idCard;
@dynamic instOfficeId;
@dynamic instOfficeName;
@dynamic assistantOfficesData;

@end
