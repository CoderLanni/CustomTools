//
//  NSString+Emoji.h
//  Assistant
//
//  Created by yiheni on 2018/8/21.
//  Copyright © 2018年 yiheni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Emoji)

+ (BOOL)stringContainsEmoji:(NSString *)string;

@end
